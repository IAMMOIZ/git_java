class A1
{
    static int i=test1() + test2();
    static int j=test1() + test2();
    public static int test1()   
    {
        System.out.println("test1:" + i +","+j);
        i=1;
        j=10;
        return i + j + test2(); 
    }
    public static int test2()  
    {
        System.out.print("test2:" + i +","+j);
        i=2;
        j=20;
        return i + j + 10; 
    }
    
    public static void main(String[]args)
    {
        System.out.println("from main:" +i);   
    }
}