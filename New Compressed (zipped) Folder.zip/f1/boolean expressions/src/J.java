class J 
{
	public static void main(String[] args) 
	{
		int i = 0;
		System.out.println((++i == 0) && (++i == 2));
		System.out.println(i);
	}
}
