class B 
{
	public static void main(String[] args) 
	{
		System.out.println(!true);
		System.out.println(!false);
	}
}
