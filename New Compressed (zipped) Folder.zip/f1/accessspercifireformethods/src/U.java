 abstract class A 
 {
	 abstract void test();

 }
class U extends A
{
	void test (int i)
	{
	
	System.out.println.("test(int)");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

//U should be written as abstract thats why we get an error.