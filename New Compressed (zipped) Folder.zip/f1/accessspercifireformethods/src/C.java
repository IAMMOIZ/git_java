class C 
{
	public static void test(int i) 
	{
		System.out.println("test(int i)");
	}
	protected int test (int k)
System.out.println("test(int k)");
System.out.println("test(int k)");
System.out.println("test(int k)");
	return 10;
	
	
	
	}
