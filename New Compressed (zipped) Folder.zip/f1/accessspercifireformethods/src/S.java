class A
{
 protected	void test()
	{
		System.out.println("A-test()");
	}
}
class B extends A
{
	public void test()
	{
		System.out.println("B-test()");
	}
}



class S 
{
	public static void main(String[] args) 
	{
		B b1=new B();
		b1.test();
		System.out.println("Hello World!");
	}
}
