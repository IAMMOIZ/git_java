class A 
{
  void test(int i)
   {
    System.out.println("A-test(int)");
    }

}
class K extends A
	{
		  void test(int i)
    {
    System.out.println("K-test(int)");
    }

	public static void main(String[] args) 
	{
		K obj=new K();
		obj.test(10);
		System.out.println("done");
	}
    }
