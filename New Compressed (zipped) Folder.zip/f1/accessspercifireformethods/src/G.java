class G 
{
	public static void main(String[] args) 
	{
		System.out.println("String[]");

	}

	public static void main(String args) 
	{
		System.out.println("String");

	}
	private int main(int args)
	{
	System.out.println("String");
	return args;
	}


}
