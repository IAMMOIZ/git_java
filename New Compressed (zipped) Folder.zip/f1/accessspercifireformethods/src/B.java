class B 
{
	public static void test() 
	{
		System.out.println("test()");
	}
	protected int  test() 
	{
		System.out.println("test()");
		System.out.println("test()");
		System.out.println("test()");
		return 10;
	}




}
