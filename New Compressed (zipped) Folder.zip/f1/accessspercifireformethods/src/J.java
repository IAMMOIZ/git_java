class A 
{
  void test()
   {
    System.out.println("A-test()");
    }

}
class J extends A
	{
		  void test(int i)
    {
    System.out.println("J-test(int)");
    }

	public static void main(String[] args) 
	{
		J obj=new J();
		obj.test();
		System.out.println("done");
	}
    }
