  class A 
 {
	  void test()
	 {
		 System.out.println("A-test()");
	 }
}
  class X extends A
{
	void test ()
	{
	System.out.println("X-test()-begin");
	super.test();
	System.out.println("W-test()-end");
	}
	public static void main(String[] args) 
	{

		X obj=new X();
		obj.test();
	}
}

