  class A 
 {
	  void test1()
	 {
		 System.out.println("A-test1()");
	 }

	  void test2()
	 {
		 System.out.println("A-test2()");
	 }


}
  class Y extends A
{
	void test1()
	{
	System.out.println("X-test1()-begin");
	super.test1();
	super.test2();
	test2();
	System.out.println("X-test1()-end");
	}
	public static void main(String[] args) 
	{

		Y obj=new Y();
		obj.test1();
	}
}

