 abstract class A 
 {
	 abstract void test();

 }
 abstract class V extends A
{
	void test (int i)
	{
	
	System.out.println("test(int)");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

