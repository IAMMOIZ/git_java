class A 
{
  void test(int i)
   {
    System.out.println("A-test(int)");
   
	}

}
class N extends A
	{
		int  test(int i,int j)
    {
    System.out.println("N-test(int,int)");
	return 10;
	}

	public static void main(String[] args) 
	{
		N obj=new N();
		obj.test(10);
		System.out.println("done:");
	}
    }
