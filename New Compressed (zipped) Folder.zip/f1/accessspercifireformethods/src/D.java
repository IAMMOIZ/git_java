 abstract class D 
{
	public  void test() 
	{
		System.out.println("Hello World!");
	}
void test(int i)
	{
System.out.println("Hello world!");

}

abstract void test(int i,int j);
static void test(String s1)
	{
    }


}
