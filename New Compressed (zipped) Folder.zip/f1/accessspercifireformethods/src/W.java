  class A 
 {
	  void test()
	 {
		 System.out.println("A-test()");
	 }
}
  class W extends A
{
	void test ()
	{
	
	System.out.println("W-test()");
	}
	public static void main(String[] args) 
	{

		W w1=new W();
		w1.test();
	}
}

