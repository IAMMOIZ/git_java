class U 
{
	int param;

	void setParam(int param)
	{
		// param = param; // local param so local gets more preferred
		this.param = param; // local param value assigning to global param
	}

	int getParam()
	{
		return param;
	}

	public static void main(String[] args) 
	{
		U u1 = new U();
		u1.setParam(10);
		System.out.println(u1.getParam());
	}
}
//if local and global static both have same name then use the class name to refer to the global 
//if local and global non-static both have same name then use this.classname