class H 
{
	static int counter;
	H()
	{
	}
	H(int i)
	{
	}
	H(int i, int j)
	{
	}
	{
		counter ++;
	}
	public static void main(String[] args) 
	{
		H h1 = new H();
		H h2 = new H(10);
		H h3 = new H();
		H h4 = new H(2,4);
		H h5 = new H();
		H h6 = new H(2,90);
		H h7 = new H(90);
		System.out.println(H.counter);
	}
}
