class T 
{
	int param;

	void setParam(int i)
	{
		param = i;
	}

	int getParam()
	{
		return param;
	}

	public static void main(String[] args) 
	{
		T t1 = new T();
		t1.setParam(10);
		System.out.println(t1.getParam());
	}
}

// setter a variable value - setter method
