class N 
{
	N()
	{
		System.out.println("N()");
	}
	N(int i)
	{
		this();
		System.out.println("N(int)");
	}

	static
	{
		System.out.println("N.SIB");
	}

	{
		System.out.println("N.IIB");
	}

	public static void main(String[] args) 
	{
		System.out.println("main begin");
		N n1 = new N();
		System.out.println("-----------");
		N n2 = new N(20);
		System.out.println("-----------");
		System.out.println("main end");
	}
}
// non static member are also called instance
// Encapsulation :group of multiple members in a single unit,
// grouping 1 entity information in a single software unit is Encapsulation
// Entity : is a noun eg. person,project etc ..
// Entity have a property, behaviour
// Property of entity is attribute inside a class
// Behaviour of entity represent through method of a class
// if class is specific to object ======= non static
// static - height etc
// non static is used along with reference variable
// static member can used along with reference variable but non static cann't use with class name
// non static can use in other non static member without reference variable
