class S 
{
	int i;

	void test()
	{
		System.out.println("from test:" + i);
		i = 20;
	}
	public static void main(String[] args) 
	{
		S s1 = new S();
		s1.i = 10;
		System.out.println("from main:" + s1.i);
		s1.test();
		System.out.println("from main:" + s1.i);
	}
}
