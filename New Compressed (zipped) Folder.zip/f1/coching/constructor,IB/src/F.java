class F 
{
	static int i;
	F()
	{
		i++;
	}
	public static void main(String[] args) 
	{
		F f1=new F();
		F f2=new F();
		F f3=new F();
		F f4=new F();
		System.out.println(F.i);
	}
}

// static member can use anywhere 
// whenever class is loading at that time static member is also loading into memory
// to use static member u don't require any reference 
// in order to find out the total no of object created to the particular class we can use this program.

 