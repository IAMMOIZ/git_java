class L 
{
	static int counter;
	L()
	{
	}
	L(int i)
	{
		this();
	}
	{
		counter++;
	}
	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println(obj1.counter);
		L obj2 = new L(10);
		System.out.println(obj2.counter);
		L obj3 = new L(10);
		System.out.println(obj3.counter);
		L obj4 = new L();
		System.out.println(obj4.counter);
	}
}