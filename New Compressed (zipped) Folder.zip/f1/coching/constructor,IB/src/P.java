class A
{
	static int i;
}
class P 
{
	static 
	{
		A.i = 1;
	}

	{
		A.i = 2;
	}

	static void test()
	{
		A.i = 3;
	}

	void test1()
	{
		A.i = 4;
	}

	public static void main(String[] args) 
	{
		A.i = 5;
		System.out.println("Hello World!");
	}
}
