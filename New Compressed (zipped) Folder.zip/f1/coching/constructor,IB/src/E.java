class E 
{
	E()
	{
		System.out.println("E()");
	}
	E(int i)
	{
		this();
		System.out.println("E(int)");
	}
	{
		System.out.println("IIB");
	}
	public static void main(String[] args) 
	{
		E e1 = new E();
		System.out.println("------------");
		E e2 = new E(90);
	}
}

// IIB execution is not more than one time for object creation
// for every object creation if something is common we can incorporate using IIB
// because of constructor overloading IIB is there