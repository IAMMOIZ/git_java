class J 
{
	int counter;
	J()
	{
	}
	J(int i)
	{
		this();
	}
	{
		counter++;
	}
	public static void main(String[] args) 
	{
		J obj1 = new J();
		J obj2 = new J(10);
		J obj3 = new J(10);
		J obj4 = new J();
		System.out.println(obj1.counter);
		System.out.println(obj2.counter);
		System.out.println(obj3.counter);
		System.out.println(obj4.counter);
	}
}

// non-static counter is specific in object