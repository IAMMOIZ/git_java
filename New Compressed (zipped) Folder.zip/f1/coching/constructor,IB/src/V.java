class V 
{
	int i;

	V(int i)
	{
		this.i = i;
	}

	int get()
	{
		return i;
	}
	public static void main(String[] args) 
	{
		V v1 = new V(100);
		System.out.println(v1.get());
	}
}
