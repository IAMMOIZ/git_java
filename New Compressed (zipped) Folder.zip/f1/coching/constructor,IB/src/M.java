class M 
{
	static
	{
		System.out.println("M.SIB");
	}

	{
		System.out.println("M.SIB");
	}

	M()
	{
		System.out.println("M()");
	}

	public static void main(String[] args) 
	{
		System.out.println("main begin");
		M m1 = new M();
		System.out.println("----------");
		M m2 = new M();
		System.out.println("----------");
		M m3 = new M();
		System.out.println("----------");
		System.out.println("main end");
	}
}

//SIB executes only one time whenever class is loading to the memory
//initialise non static members - go for constructors or IIB
//initialise static member - go for SIB