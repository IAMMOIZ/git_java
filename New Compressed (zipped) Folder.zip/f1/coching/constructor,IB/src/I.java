class I 
{
	static int counter;
	I()
	{
		this(90);
	}
	I(int i)
	{
	}
	{
		counter ++;
	}
	public static void main(String[] args) 
	{
		I obj1 = new I();
		I obj2 = new I(10);
		System.out.println(I.counter);
	}
}
//IIB not executing constructor wise
