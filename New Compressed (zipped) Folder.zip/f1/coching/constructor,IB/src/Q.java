class Q 
{
	void test()
	{
		System.out.println("from test:" + this);
	}
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		System.out.println("from main:" + q1);
		q1.test();
	}
}

// by using q1 we r calling test method
// output - from main:Q@1db9742 = address of the object
// in test method, this = q1
// q1 is local to main method
// in every non static definiton block there is a bydefault "this"
// "this" is not available in any static members.