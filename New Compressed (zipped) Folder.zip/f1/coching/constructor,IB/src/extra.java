

this();
this(10);
this(10, 30);
this("abc","xyz");
this("abc", "xyz", 50, 5.5); // this is used to call constructor from other constructor




this.i = 10;
return this.i;
this.test(); // this here is default reference variable
// can be used anywhere but should be in non static constructor,iib,non staic method