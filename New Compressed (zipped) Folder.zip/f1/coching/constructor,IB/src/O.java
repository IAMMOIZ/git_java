class O 
{
	static int i;
	O()
	{
		i = 1;
	}

	{
		i = 2;
	}

	void test1()
	{
		i = 3;
	}
	public static void main(String[] args) 
	{
		i = 4;
		System.out.println("Hello World!");
	}
}

//static member can be used anywhere along with a class name or reference variable.
