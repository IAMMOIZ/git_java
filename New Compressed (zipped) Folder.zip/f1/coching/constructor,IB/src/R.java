class R 
{
	int i;

	void test()
	{
		System.out.println("from test:" + this.i);
		this.i = 20;
	}
	public static void main(String[] args) 
	{
		R r1 = new R();
		r1.i = 10;
		System.out.println("from main:" + r1.i);
		r1.test();
		System.out.println("from main:" + r1.i);
	}
}
