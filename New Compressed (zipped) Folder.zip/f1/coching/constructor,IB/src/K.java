class K 
{
	static int counter;
	K()
	{
	}
	K(int i)
	{
		this();
	}
	{
		counter++;
	}
	public static void main(String[] args) 
	{
		K obj1 = new K();
		K obj2 = new K(10);
		K obj3 = new K(10);
		K obj4 = new K();
		System.out.println(obj1.counter);
		System.out.println(obj2.counter);
		System.out.println(obj3.counter);
		System.out.println(obj4.counter);
	}
}