package pack2;

public class N {
public static void test3()
{
System.out.println("pack2.N.test3 begin");
assert false;
System.out.println("pack2.N.test3 end");
}
}
