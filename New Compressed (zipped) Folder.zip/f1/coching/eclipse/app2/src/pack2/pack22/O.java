package pack2.pack22;

public class O {
	public static void test4()
	{
	System.out.println("pack2.pack22.O.test4 begin");
	assert false;
	System.out.println("pack2.pack22.O.test4 end");
	}
}
