package pack1.pack11;

public class M {
	public static void test2()
	{
		System.out.println("pack1.pack11.M.test2 begin");
		assert false;
		System.out.println("pack1.pack11.M.test2 end");
	}

}
