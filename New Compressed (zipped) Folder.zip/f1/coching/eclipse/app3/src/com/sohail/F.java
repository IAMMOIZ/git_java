package com.sohail;

public class F {
public static void main(String[] args) {
	System.out.println(1);
if(true)
{

	//throw new NullPointerException("some thing went wrong");
	System.out.println("if block");

}
System.out.println(2);

}
}
