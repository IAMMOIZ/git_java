package com.sohail;

public class E {
public static void main(String[] args) {
	System.out.println(1);
if(true)
{
System.out.println("if block");
throw new NullPointerException("some thing went wrong");
}
System.out.println(2);

}
}
