package com.sohail;

public class J {
public static void main(String[] args) {
	try 
	{
		System.out.println(1);
		int i = 10/0;
		System.out.println(2);
		}
	catch(ArithmeticException ex)
	{
		System.out.println("do some thing");
		throw new ArithmeticException(ex.getMessage());
	}
}
}
