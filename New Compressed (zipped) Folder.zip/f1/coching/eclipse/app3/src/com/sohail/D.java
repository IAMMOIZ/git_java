package com.sohail;

public class D {
	public static void main(String[] args) {
		System.out.println(1);
	try
	{
		System.out.println("try begin");
	if(true)
	{
		throw new StackOverflowError("something went wrong");
	}
	System.out.println("try end");
	
	}
	catch(StackOverflowError err)
	{
		System.out.println(err);
		
	}
	
		System.out.println(2);
	}

}
