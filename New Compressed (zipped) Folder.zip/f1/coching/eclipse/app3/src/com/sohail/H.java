package com.sohail;

import java.util.Scanner;

public class H{
public static void main(String[] args) {

	Scanner sc =new Scanner(System.in);
	System.out.println("app started");
	System.out.println("enter your age");
	int age = sc.nextInt();
    if(age<=0)
    {
    	throw new ArithmeticException("age should be greater than 0");
    }
    System.out.println("age verified ..pls continue..");
}
}
