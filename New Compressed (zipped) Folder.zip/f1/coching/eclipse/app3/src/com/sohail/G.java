package com.sohail;
import java.util.Scanner;
public class G {
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	System.out.println("app started");
	System.out.println("enter your age");
	int age=sc.nextInt();
    if(age<=0);
    {
    	throw new ArithmeticExcetion();
    }
    System.out.println("age verified ..pls continue..");
}
}
