package com.sohail;

public class AgeIsNegativeException extends RuntimeException 
{
public AgeIsNegativeException()
{
	
}
public AgeIsNegativeException(String msg)

{
super(msg);	
}
}
