package com.sohail;

public class C {
	public static void main(String[] args) {
		System.out.println(1);
		if(true)
		{
			throw new StackOverFlowError("some thing went wrong")
		}
		System.out.println(2);
	}

}
