package com.sohail;

import java.util.Scanner;

public class I {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		System.out.println("app started");
		System.out.println("enter your age");
		int age = sc.nextInt();
	    if(age<=0)
	    {
	    	throw new AgeIsNegativeException("age should be greater than 0");
	    }
	    System.out.println("age verified ..pls continue..");
	}
}

/*

-catch arg should be throwable type 
-throws also should be throwable type
-throw also should be throwable type.
- 
 
 */