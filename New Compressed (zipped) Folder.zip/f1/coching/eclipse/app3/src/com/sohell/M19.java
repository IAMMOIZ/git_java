package com.sohell;

public class M19 {
public static void main(String[] args) {
	try {
		System.out.println(1);
		Class.forName("");
		System.out.println(2);
	}
	catch(ClassNotFoundException ex) 
	{
		System.out.println(ex);
	}
	System.out.println("done");
}
}
