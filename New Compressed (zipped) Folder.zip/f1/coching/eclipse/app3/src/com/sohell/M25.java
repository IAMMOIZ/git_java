package com.sohell;

public class M25 {
public static void main(String[] args) {
	try
	{
		
	}
	catch(ClassNotFoundException ex)
	{
		ex.printStackTrace();
	}
}
}
