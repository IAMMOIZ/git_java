package com.sohell;

public class M13 {
	public static void main(String[] args) {
		System.out.println(1);
		test1();
		System.out.println(2);
		
	}
	static void test1()
	{
		System.out.println(3);
		try
		{
			int i=10/0;
			
		}
		catch(ArithmeticException ex)
		{
		System.out.println(ex);
		}
		System.out.println(4);
	}

}
