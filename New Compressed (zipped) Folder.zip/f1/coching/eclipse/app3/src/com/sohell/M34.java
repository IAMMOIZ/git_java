package com.sohell;

public class M34 {
M34() throws ClassNotFoundException
{
	
}

	public static void main(String[] args) throws ClassNotFoundException
	
	{
		M34 obj=new M34();
   
}
}
