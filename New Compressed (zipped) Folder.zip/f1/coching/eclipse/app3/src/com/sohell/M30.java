package com.sohell;

public class M30 {
	public static void main(String[] args) 
	{
		try
		
		{
			test();
		}
		catch(ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
	}
	static void test() throws ClassNotFoundException
	{
		
	}

}
