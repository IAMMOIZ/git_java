package com.sohell;

public class M21 {
public static void main(String[] args) {
	System.out.println(1);
	test1();
	System.out.println(2);
}
static void test1() 
{
System.out.println(3);
try
{
Class.forName("");
}
catch(ClassNotFoundException ex) 
{
ex.printStackTrace();	
}
System.out.println(4);
}
}
