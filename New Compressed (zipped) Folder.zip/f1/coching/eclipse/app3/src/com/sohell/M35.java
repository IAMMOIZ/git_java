package com.sohell;
class A
{
A() throws ClassNotFoundException	
{}
}
public class M35 extends A
{
public static void main(String[] args) {
	System.out.println("done");
}
}
