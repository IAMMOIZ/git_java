package com.sohell;

public class M23 {
public static void main(String[] args) {
	System.out.println(1);
try 
{
System.out.println("try begin");
test1();
System.out.println("try end");
}
catch(ClassNotFoundException ex)	
{
System.out.println(ex);

}	
System.out.println(2);	
	
}
static void test1()  throws ClassNotFoundException
{
System.out.println(3);
Class.forName("");
System.out.println(4);
}
}
