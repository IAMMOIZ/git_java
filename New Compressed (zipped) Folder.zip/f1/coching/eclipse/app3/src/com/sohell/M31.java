package com.sohell;

public class M31 {
	public static void main(String[] args) throws ClassNotFoundException
	{
		test();
	}
	static void test() throws ClassNotFoundException
	{
		
	}

}
