package com.sohell;

public class M18 {
public static void main(String[] args) {
	Class.forName("");
}
}
