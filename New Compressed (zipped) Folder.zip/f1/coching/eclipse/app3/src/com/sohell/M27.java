package com.sohell;

public class M27 {
public static void main(String[] args) throws ClassNotFoundException
{
}
}
