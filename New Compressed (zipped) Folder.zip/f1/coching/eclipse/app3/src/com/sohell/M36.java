package com.sohell;
class B
{
B() throws ClassNotFoundException
{
	
}
}
public class M36 extends B 
{
M36() throws ClassNotFoundException
{
super();	
}
public static void main(String[] args) {
	System.out.println("done");
}
}
