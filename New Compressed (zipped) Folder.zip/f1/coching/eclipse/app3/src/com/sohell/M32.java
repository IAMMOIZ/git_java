package com.sohell;

public class M32 {
M32() throws ClassNotFoundException
{
	
}

	public static void main(String[] args) {
 //M32 obj=new M32();	
}
}
