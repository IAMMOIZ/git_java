package com.sohell;

public class M29 {
	public static void main(String[] args) 
	{
	//	test();
	}
	static void test() throws ClassNotFoundException
	{
		
	}

}
