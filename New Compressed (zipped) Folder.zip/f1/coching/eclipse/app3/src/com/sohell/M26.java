package com.sohell;

public class M26 {
public static void main(String[] args) {
	try
	{
		System.out.println("hello");
	    int i=20;
	}
	catch(ClassNotFoundException ex)
	{
		ex.printStackTrace();
	}
}
}
