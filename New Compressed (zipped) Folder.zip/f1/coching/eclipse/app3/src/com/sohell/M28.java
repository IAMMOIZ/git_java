package com.sohell;

public class M28
{
	M28() throws ClassNotFoundException
	{
		
	}
	
public static void main(String[] args) 
{
	
}
static void test() throws ClassNotFoundException
{
	
}
}
