package com.sohell;

public class M9 {
public static void main(String[] args)
{
try {}
catch(NoClassDefFoundError ex)
{
	ex.printStackTrace();
}
System.out.println("done");
}
	
}
