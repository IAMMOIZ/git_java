package com.sohell;

public class M8 {
public static void main(String[] args)
{
int[] elements=new int[999999999];
System.out.println("done");
}
}
