package com.sohell;

public class M7 
{
public static void main(String[] args)
{
	System.out.println("hi");
}
}

