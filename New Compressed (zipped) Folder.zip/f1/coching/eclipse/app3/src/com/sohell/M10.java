package com.sohell;

public class M10 {

	public static void main(String[] args) {
		String s1= args[0];
		System.out.println("done");
	}
}
