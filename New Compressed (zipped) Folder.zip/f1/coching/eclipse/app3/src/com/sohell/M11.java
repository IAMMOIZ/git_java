package com.sohell;

import java.util.Scanner;

public class M11 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter int value");
	int i =sc.nextInt();
	int j=i/(i-9);
	System.out.println(j);
}
}
