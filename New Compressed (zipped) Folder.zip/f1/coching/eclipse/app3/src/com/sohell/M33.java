package com.sohell;

public class M33 {
M33() throws ClassNotFoundException
{
	
}

	public static void main(String[] args) {
   try
   {
	   M33 obj= new M33();
	   
   }
   catch(ClassNotFoundException ex)
   {
	   ex.printStackTrace();
   }
}
}
