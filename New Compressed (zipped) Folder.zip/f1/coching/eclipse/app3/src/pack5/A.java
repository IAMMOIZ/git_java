package pack5;

public class A {
	public static void main(String[] args) {
		System.out.println(1);
		assert false;
		System.out.println(2);
		
	}

}
