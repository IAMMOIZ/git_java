package pack5;

public class D {
public static void main(String[] args) {
//	int assert = 10;
//	System.out.println(assert);
	
}
}
