package pack5;

public class B {
	public static void main(String[] args) {
		System.out.println(1);
		assert false : "went wrong";
		System.out.println(2);
		
	}

}
