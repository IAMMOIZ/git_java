class B5 
{
int test()
{
try
{
	//several statements
return 20;
}
catch (ArithmeticException ex)
{
	
}
	
}
}
