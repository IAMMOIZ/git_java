class C1 
{
int test()
{
try
{
//several statements
return 10;
}
catch (ArithmeticException ex)
{
}
finally
{
}
return 40;
}
}
