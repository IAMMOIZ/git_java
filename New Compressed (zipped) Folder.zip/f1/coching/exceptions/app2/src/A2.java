class A2
{
	int test(boolean flag)
	{   
		if (flag)
       {
		return 10;
       }
	return 20;
	
	}
	}
//compilation success.