class B 
{
int test()
{
try
{
	//several statements
}
catch (ArithmeticException ex)
{
}
return 10;
}
}
