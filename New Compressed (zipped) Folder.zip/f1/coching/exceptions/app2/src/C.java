class C 
{
int test()
{
try
{
	//several statements

}
catch (ArithmeticException ex)
{
}
finally
{
}
return 40;
}
}
