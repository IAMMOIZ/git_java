class A 
{
	int test(boolean flag) 
	{
		return 10;
		}
}
