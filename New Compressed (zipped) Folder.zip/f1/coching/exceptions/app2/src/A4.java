class A4
{
	int test(boolean flag)
	{   
		if (flag)
       {
		
		}

	else
	{
		return 20;
	}
	return 20;
	}
	}
