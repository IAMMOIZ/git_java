class B4 
{
int test()
{
try
{
	//several statements
return 20;
}
catch (ArithmeticException ex)
{
	
}
	return 30;
}
}
