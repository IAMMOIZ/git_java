class A5
{
	int test(boolean flag)
	{   
		if (flag)
       {
			return 20;
		
		}

	else
	{
	}
	return 10;
	}
	}
