class B2 
{
int test()
{
try
{
	//several statements

}
catch (ArithmeticException ex)
{
	return 20;
}
return 10;
}
}
