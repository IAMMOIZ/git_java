class B3 
{
int test()
{
try
{
	//several statements

}
catch (ArithmeticException ex)
{
	return 20;
}
}
}
