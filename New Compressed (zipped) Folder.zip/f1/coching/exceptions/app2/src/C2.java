class C2 
{
int test()
{
try
{
//several statements

}
catch (ArithmeticException ex)
{
	return 10;
}
finally
{
}
return 40;
}
}
