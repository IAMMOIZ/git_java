class C7 
{
int test()
{
try
{
//several statements

}
catch (ArithmeticException ex)
{
	
}
finally
{	
return 40;
}
return 10;
}
}
//if there is a statement in finally then you cannot keep any statement after finally.
