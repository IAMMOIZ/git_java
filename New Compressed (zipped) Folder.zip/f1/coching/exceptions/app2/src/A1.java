class A1
{
	int test(boolean flag)
	{   
		if (flag)
       {
		return 10;
       }
	
	
	}
	}
