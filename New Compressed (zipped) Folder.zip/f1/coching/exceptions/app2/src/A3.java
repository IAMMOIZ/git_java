class A3
{
	int test(boolean flag)
	{   
		if (flag)
       {
		return 10;
       }

	else
	{
		return 20;
	}
	}
	}
