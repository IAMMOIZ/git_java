class H
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
       int[] x= new int[999999999];
		 System.out.println("main end");
	
	
		

	}
}
