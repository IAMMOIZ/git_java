class Z14
{
	    public static void main(String[] args) 
	    {
		System.out.println("main begin");
     	
		try
		{
		System.out.println(1);
		int i=10/0;
		System.out.println(2);
		
		}	
             finally              
			{
             System.out.println(3);  
		    }
        System.out.println("main end:"); 
	}
}

//try and finally is allowed
//try without any catches is allowed but with finally but no try and catch alone should be in the programs.
//without try nothing is possible like to put catches.
/* this are the possiblities->
try-catch
try-catch-finally
try-catches
try-catches-finally
try-finally
*/