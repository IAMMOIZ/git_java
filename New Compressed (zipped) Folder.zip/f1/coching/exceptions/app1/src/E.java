class E 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Object obj=new Object();
		E e1=(E) obj;
		 
		 System.out.println("main end");
	
	
		

	}
}
//obj is referring to obj class object