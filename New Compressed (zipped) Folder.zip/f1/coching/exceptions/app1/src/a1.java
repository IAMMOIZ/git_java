class a
{
public static void main(String gg[])
{
int i=0;
try{
System.out.println(1);
i=10/0;
System.out.println(2);
}catch (ArithmeticException ex)
{
System.out.println(3);
i=2;
System.out.println(4);}

System.out.println(5);
}
}