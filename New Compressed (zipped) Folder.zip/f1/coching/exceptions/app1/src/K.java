class K 
{
	//static int x;
}
