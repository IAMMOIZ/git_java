class Z12
{
	    public static void main(String[] args) 
	    {
		System.out.println("main begin");
     	
		try
		{
		System.out.println(1);
		System.exit(0);        //exit is a static method in a system class.//it require integer argument.
		System.out.println(2);
		
		}
		catch (ArithmeticException ex) //Throwable
	    	{
			System.out.println(3);
			}
             finally              
			{
             System.out.println("from finally");  //finally block is not executing.
		    }
        System.out.println("main end:"); 
	}
}


//whenever system.exit command is executing control is finished there.