class I
{
}


class J
{
	public static void main(String[] args) 
	{
		
		System.out.println("main begin");
        I obj= new I();
		System.out.println("main end");
	
	
		

	}
}
