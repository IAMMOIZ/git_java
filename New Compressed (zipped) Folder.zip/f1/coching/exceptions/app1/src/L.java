class L 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		K.x=20;
		System.out.println("main end");
	}
}
