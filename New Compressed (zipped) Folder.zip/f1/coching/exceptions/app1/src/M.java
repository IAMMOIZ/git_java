class M 
{
	
/*	void test()
	{
	}
*/
}
