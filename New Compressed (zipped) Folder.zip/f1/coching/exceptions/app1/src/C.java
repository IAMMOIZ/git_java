class C 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
       int i=Integer.parseInt("abc");
         System.out.println("main end");
	
	
		

	}
}
