class Z9
{
	    public static void main(String[] args) 
	    {
		System.out.println("main begin");
		
		try
		{
		System.out.println(1);
		return;
		}
		catch (ArithmeticException ex) //Throwable
		{
			System.out.println(2);
		}
             finally              
			{
             System.out.println("from finally");
		    }
        System.out.println("main end:"); 
	}
}

//it is not returning from the try body itself once flow go inside.

