class Z7
{
	    public static void main(String[] args) 
	    {
		System.out.println("main begin");
	int i;	try
		{
		System.out.println(1);
		
	 i=10/0;
		System.out.println(2);
		}
		catch (ArithmeticException ex) //Throwable
		{
			System.out.println(3);
		    ex.printStackTrace();
			i=10;
		    System.out.println(4);
		}
          //   finally              
			//{
             //System.out.println("from finally");
		    //}
        System.out.println("main end:"); 
	}
}



