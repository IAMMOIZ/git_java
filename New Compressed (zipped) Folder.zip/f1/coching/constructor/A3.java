class A2
{ 
	int age;
	A2( int x)
	{
		this.age=x;
	    System.out.println("From A2"+age);
		
	}
	A2()
	{
	   System.out.println("From A21");
	}
}
class A3 extends A2 
 {
	 
	 A3(int x)
	 {
		 int age;
	   age=x;
	   System.out.println("From 3 param:"+age);
	 }
     
	 A3()
	 {
	    	  
	    System.out.println("From A3");
	 }
	public static void main(String[] args)
	{
		A3 a = new A3(34);

	     
	}
}