class myClass
{
	String name;
	int id;
	myClass()
	{
	System.out.println("hi");
	}
	myClass(String x ,int y)
	{
	   this.name=x;
	   this.id=y;
	}
	public static void main(String[] sohail)
	{
	  myClass my=new myClass();
      myClass my1=new myClass("raj",101);
      System.out.println("Name is>"+my1.name+ "  Id is>"+my1.id);
	}
}