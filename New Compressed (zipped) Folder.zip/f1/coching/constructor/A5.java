class A4
{
	static void myMethod()
	{
	System.out.println("hi");
	}
}
class A5
{
	public static void main(String[] args)
	{
	   A4 a=new A4();
	   a.myMethod();
	
	}
}