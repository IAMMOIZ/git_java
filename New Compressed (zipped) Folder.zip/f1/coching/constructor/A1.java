class A1 
{ 
     String s;
	 int s1;
     public A1(int age ,String name)
	{
	      this.s1=age;
		  this.s=name;
	 }
	 void info()
	{
	 System.out.println("age:"+s1+ "Name:"+s);
	 }
	
	public static void main(String[] args) 
	{
	     A1 a=new A1(12,"Sohail");
        a.info();

	}
}
