class P 
{
	P(int i, int j)
	{
		System.out.println("P(int, int)");
	}
	P(int i, double j)
	{
		System.out.println("P(int, double)");
	}
	P(double i, int j)
	{
		System.out.println("P(double, int)");
	}
	P(double i, double j)
	{
		System.out.println("P(double, double)");
	}
	public static void main(String[] args) 
	{
		P p1 = new P(1,2);
		System.out.println("------------");
		P p2 = new P(1,2.0);
		System.out.println("------------");
		P p3 = new P(1.0,2.0);
		System.out.println("------------");
		P p4 = new P(1.0,2);
		System.out.println("------------");
	}
}
