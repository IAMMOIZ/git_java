class N 
{
	N(int i)
	{
		System.out.println("N(int)");
	}
	N(double i)
	{
		System.out.println("N(double)");
	}
	public static void main(String[] args) 
	{
		N n1 = new N(90);
		System.out.println("------------");
		N n2 = new N(9.0);
		System.out.println("------------");
	}
}

