class J 
{
	public static void main(String[] args) 
	{
		J j1 = new J();
		System.out.println("-----------");
		J j2 = new J();
	}
}

// if no constructor are there in class then compiler will providing no argument constructor as default.
