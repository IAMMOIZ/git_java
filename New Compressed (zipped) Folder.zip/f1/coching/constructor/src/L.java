class L 
{
	L(90)
	{
	}
	public static void main(String[] args) 
	{
		L obj = new L();
		System.out.println("done");
	}
}

//compiler will not providing default constructor if already argument constructor is there.
