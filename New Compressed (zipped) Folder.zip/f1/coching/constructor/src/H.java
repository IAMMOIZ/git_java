class H 
{
	int i;
	double j;
	H(int x, double y)
	{
		i = x;
		j = y;
	}
	public static void main(String[] args) 
	{
		H h1 = new H(10, 1.5);
		H h2 = new H(1, 5.5);
		System.out.println(h1.i + ", " + h1.j);
		System.out.println(h2.i + ", " + h2.j);
	}
}
