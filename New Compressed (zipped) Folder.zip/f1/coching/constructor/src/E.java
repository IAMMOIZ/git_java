class E 
{
	int i;
	double j;
	E()
	{
		i=10;
		j=1.5;
	}
	public static void main(String[] args) 
	{
		E e1= new E();
		System.out.println(e1.i + ", " + e1.j);
	}
}

// constructor are mainly used for initialising non-static members.