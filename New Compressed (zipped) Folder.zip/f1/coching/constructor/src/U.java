class U 
{
	U()
	{
		this(90);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// give compile time error because this calling stmt looking for integer argument constructor
