class X 
{
	X()
	{
	}
	void test()
	{
		this();
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// this calling stmt only in the constructor body(not in method body) to call other constructor 
// by choosing differnt signature u can develop multiple constructor
