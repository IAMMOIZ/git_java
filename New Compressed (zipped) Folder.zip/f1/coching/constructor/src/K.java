class K 
{
	public static void main(String[] args) 
	{
		K k1 = new K(90);
		System.out.println("done");
	}
}


