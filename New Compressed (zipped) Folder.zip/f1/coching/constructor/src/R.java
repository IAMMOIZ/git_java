class R 
{
	R()
	{
		System.out.println("R()");
	}
	R(int i)
	{
		this(); //almost like method calling statement will call to current class no arg constructor
		System.out.println("R(int)");
	}
	public static void main(String[] args) 
	{
		R r1 = new R();
		System.out.println("------------");
		R r2 = new R(90);
	}
}

// for using multiple constructors we have to use "this()"