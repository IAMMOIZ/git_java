class G 
{
	int i;
	G(int x)
	{
		i = x;
	}
	public static void main(String[] args) 
	{
		G g1 = new G(9);
		System.out.println(g1.i);
		G g2 = new G(19);
		System.out.println(g2.i);
		G g3 = new G(91);
		System.out.println(g3.i);
	}
}

// we can develops constructor with arguments but return type is not necessary