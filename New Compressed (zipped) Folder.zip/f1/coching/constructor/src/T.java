class T 
{
	T()
	{
		System.out.println("T()");
	}
	T(int i)
	{
		i=10;
		this();
		System.out.println("T()");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// this calling stmt should be first stmt in the constructor body