class A 
{
	A() //constructor should have same name as class name
	{
		System.out.println("A()");
	}
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println("--------------");
		A a2 = new A();
	}
}

// constructor shouldn't have a return type
// constructor executing automatically while object is created
// constructor shouldn't be static , always non-static