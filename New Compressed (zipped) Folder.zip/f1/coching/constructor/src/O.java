class O 
{
	O(int i)
	{
		System.out.println("O(int)");
		System.out.println("O(int)");
	}
	O(int j)
	{
		System.out.println("O()");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// constructor always looking for no of signatures 