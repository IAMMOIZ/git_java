class S 
{
	S()
	{
		this(90);
		System.out.println("S()");
	}
	S(double i)
	{
		System.out.println("S(int)");
	}
	public static void main(String[] args) 
	{
		S s1 = new S();
		System.out.println("-----------");
		S s2 = new S(100);
		System.out.println("-----------");
	}
}
