class V 
{
	V()
	{
		this(90);
	}
	V(int i)
	{
		this();
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// this stmt here is in cyclic/recursive 
// recursive is not allowed in case of constructor.
