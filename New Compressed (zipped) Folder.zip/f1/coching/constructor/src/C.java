class C 
{
	C()
	{
		System.out.println("C()");
	}
	public static void main(String[] args) 
	{
		C c1 = new C();
		System.out.println("-------------");
		C c2 = c1;
		System.out.println("-------------");
		C c3 = c1;
		System.out.println("-------------");
		C c4 = c2;
	}
}

// while object is creating at that time only constructor executes