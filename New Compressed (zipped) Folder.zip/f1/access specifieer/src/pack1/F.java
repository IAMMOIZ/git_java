package pack1;
class A 
{
	private int i;
}
class F extends A
{
	public static void main(String[] args)
	{
		F f1 = new F(); 
		System.out.println(f1.i);
	}
}

//error: i has private access in A
// private member cann't be inheriting 