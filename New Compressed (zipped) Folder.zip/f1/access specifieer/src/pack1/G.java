package pack1;
class A
{
	private void test1()
	{
	}
}
class G extends A
{
	public static void main(String[] args) 
	{
		G g1 = new G();
		g1.test1();
		System.out.println("done");
	}
}

// no private member is involving in inheritance