package pack1;
class C 
{
	private C()
	{
		System.out.println("C()");
	}
}
class E extends C
{
	public static void main(String[] args)
	{
		//C c1 = new C(); 
		System.out.println("Hello World!");
	}
}

//private members cann't be called from outside a current class even though the outdise is a sub class

