package pack1;
class C 
{
	private C()
	{
		System.out.println("C()");
	}
}
class D
{
	public static void main(String[] args)
	{
		C c1 = new C(); // calling stmt
		System.out.println("Hello World!");
	}
}

// if the constructor is private so we cann't develop calling stmt outside class C
// if constructor is private object creation should be within the same class
