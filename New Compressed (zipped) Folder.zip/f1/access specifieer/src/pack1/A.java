package pack1;
class A 
{
	private int i;
	private void test1()
	{
		System.out.println("A-test1()");
	}
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println(a1.i);
		a1.test1();
	}
}

// private member of any class should be use within the same class ,cann't use outside the class
