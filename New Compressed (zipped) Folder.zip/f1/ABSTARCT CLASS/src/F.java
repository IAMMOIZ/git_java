abstract class A
{
	void test()
	{
		System.out.println("A-test()");
	}
}
class F 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		a1.test();
		System.out.println("Hello World!");
	}
}

// test() method is non static , we cann't use test() straight away even though test() is fully implemented.
// non static can be used only for object creation
// if it is non static member then use reference variable
