abstract class A
{
	abstract void test1();
	abstract void test2();
}  
class B extends A
{
	void test1()
	{
		System.out.println("B-test1()");
	}
}
class N
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
