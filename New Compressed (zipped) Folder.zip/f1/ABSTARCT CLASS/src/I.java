abstract class A
{
	static void test()
	{
		System.out.println("A-test()");
	}
}
class I 
{
	public static void main(String[] args) 
	{
		A a1 = null;
		a1.test(); 
		System.out.println("Hello World!");
	}
}

// every static member should be used along with class name not with refernce variable as refernce variable should be created
// 