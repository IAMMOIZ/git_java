abstract class A
{
}
class B 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

// for abstract class also class file is generating while compiling
// non abstract means concreate
// A is a abstract class, B is a concreate class
// in java file any no. of abstract class , any no of concreate classes
// while compiling class file generating both class abstract and concreate