abstract class A
{
}
class E 
{
	E(A a1)
	{
	}
	static void test1(A obj)
	{
	}
	static A test2()
	{
		return null;
	}
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}

// usage of class is to create an object