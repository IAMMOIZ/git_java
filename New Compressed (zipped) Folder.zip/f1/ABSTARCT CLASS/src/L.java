abstract class L 
{
	abstract void test() 
	{
		System.out.println("Hello World!");
	}
}

// method should have implement either abstract or keyword
// implement method should not have a abstract if it is then we'll get compile time error