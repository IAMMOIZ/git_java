abstract class A
{
	void test()
	{
		System.out.println("A-test()");
	}
}
class H 
{
	public static void main(String[] args) 
	{
		A a1 = null;
		A.test(); 
		System.out.println("Hello World!");
	}
}