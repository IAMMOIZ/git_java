abstract class A
{
	abstract void test1();
	abstract void test2();
}  
abstract class B extends A
{
	void test1()
	{
		System.out.println("B-test1()");
	}
}
class O
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
