abstract class A
{
	void test()
	{
		System.out.println("A-test()");
	}
}
class G 
{
	public static void main(String[] args) 
	{
		A a1 = null;
		a1.test(); //abnormal condition
		System.out.println("Hello World!");
	}
}

// compiler won't allow object to abstract class
// a1 is local to main so a1 should be initialised.
// whenever abnormal condition is applied we get run time error