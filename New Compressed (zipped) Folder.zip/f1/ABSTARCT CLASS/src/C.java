abstract class A
{
}
class C 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		C c1 = new C();
		System.out.println("done");
	}
}
 
// compiler will not allow to create a object for abstract class