abstract class A
{
	abstract void test1();
	abstract void test2();
}  
class B extends A
{
	void test1()
	{
		System.out.println("B-test1()");
	}
	void test2()
	{
		System.out.println("B-test2()");
	}
}
class Q
{
	public static void main(String[] args) 
	{
		B b1 = new B();
		b1.test1();
		System.out.println("-----------");
		b1.test2();
	}
}

// when constructor is executing-while object is creating to the current class or to the sub class of the particular class
// constructor should not be static 
// constructor are not loading when class is loading
