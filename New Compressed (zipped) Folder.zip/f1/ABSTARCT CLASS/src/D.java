abstract class A
{
}
class D 
{
	public static void main(String[] args) 
	{
		A a1 = null;
		System.out.println("done");
	}
}

// we can create reference variable to the abstract class , we cann't create object
// abstract class can be used as a derived datatype 
// wherever datatype is required we can use abstract class
