abstract class S
{
	abstract void test1();
	abstract void test2();
	abstract void test3();
	abstract void test4();
	abstract void test5();
}

// no class can be 100% abstract even though every method is abstract
// reason-because even abstract method should have min 1 constructor
// we can achieve 100% abstract by interface