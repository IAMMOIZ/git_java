class K 
{
	abstract void test();
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

//K is not abstract and does not override abstract method test() in K class K