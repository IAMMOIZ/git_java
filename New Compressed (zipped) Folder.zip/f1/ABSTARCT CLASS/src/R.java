abstract class A
{
	A()
	{
		System.out.println("A()");
	}
}
abstract class B extends A
{
	B()
	{
		System.out.println("B()");
	}
}
class R extends B
{
	R()
	{
		System.out.println("R()");
	}
	public static void main(String[] args) 
	{
		R r1 = new R();
		System.out.println("Hello World");
	}
}

// we can create any no. of constructor even though class is abstract