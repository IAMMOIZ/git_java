class  E
{
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		for(int i=1; i<=5; i++)
		{
			System.out.println("outer begin:"+i);
			for(int j=20; j<= 22; j++)
			{
				System.out.println("innre begin:"+i+","+ j);
				if(j==21)
				{
					continue;
				}
				System.out.println("innre end:"+i+","+ j);
		}
		System.out.println("outer end:"+i);
		System.out.println("==========");
	}
		System.out.println("main-end");
	}
}
