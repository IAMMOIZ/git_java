class  A
{
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		for(int i=1;i<=5; i++)
		{
			System.out.println("begin:"+i);
			if(i==3)
			{
				System.out.println("if block:"+i);
			continue;
		}
		System.out.println("end:"+i);
		}
		System.out.println("main-end");
			}
}
