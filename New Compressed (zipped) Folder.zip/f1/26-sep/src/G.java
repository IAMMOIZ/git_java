class  G
{
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		loop1:
		for(int i=1; i<=5; i++)
		{
			System.out.println("outer begin:"+i);

			xyz:

			for(int j=20; j<= 22; j++)
			{
				System.out.println("innre begin:"+i+","+ j);

				if(j==21)

				{
					continue loop1;
				}

				System.out.println("innre end:"+i+","+ j);
		}

		System.out.println("outer end:"+i);

		System.out.println("==========");
	}
		System.out.println("main-end");
	}
}
//When we want to control outer loop from inner loop we must specified the outer loop name inside the inner loop with continue or break.