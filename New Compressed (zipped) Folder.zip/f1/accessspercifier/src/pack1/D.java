package pack1;

class D extends C 
{
	public static void main(String[] args) 
	{

		D d1=new D();
		System.out.println(d1.x);
		System.out.println(d1.y);
		System.out.println(d1.z);
	}
}
