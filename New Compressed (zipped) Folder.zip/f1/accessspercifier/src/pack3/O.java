package pack3;
import pack2.N;
class O extends N
{
	public static void main(String[] args) 
	{
		O obj1 = new O();
		System.out.println(obj1.y);
		System.out.println(obj1.z);
		


	}
}
