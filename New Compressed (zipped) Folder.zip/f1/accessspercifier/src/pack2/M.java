package pack2;
class  M extends L
{
	public static void main(String[] args) 
	{
		M obj1 =new M();
	    //System.out.println(obj1.x);
		System.out.println(obj1.y);
		System.out.println(obj1.z);
	}
}
