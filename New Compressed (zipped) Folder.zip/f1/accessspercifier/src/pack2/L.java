package pack2;
import pack1.*;
class  L extends A
{
	public static void main(String[] args) 
	{
		L obj1 =new L();
	    //System.out.println(obj1.x);
		System.out.println(obj1.y);
		System.out.println(obj1.z);
	}
}
