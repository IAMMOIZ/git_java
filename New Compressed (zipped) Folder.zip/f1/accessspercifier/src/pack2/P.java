package pack2;
class  P
{
	public static void main(String[] args) 
	{
		L obj1= new L();
		System.out.println(obj1.y);
		System.out.println(obj1.z);
		
        M obj2= new M();
		System.out.println(obj2.y);
		System.out.println(obj2.z);
		
		N obj3= new N();
		System.out.println(obj3.y);
		System.out.println(obj3.z);
		
		

	}
}
