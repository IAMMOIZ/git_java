package pack2;
import pack1.*;
class  K extends A
{
	public static void main(String[] args) 
	{
		A a1 =new A();
		System.out.println(a1.x);
		System.out.println(a1.y);
		System.out.println(a1.z);
	}
}
