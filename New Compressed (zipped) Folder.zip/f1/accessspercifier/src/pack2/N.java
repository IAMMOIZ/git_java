package pack2;
 public class  N extends L
{
	public static void main(String[] args) 
	{
		N obj1 =new N();
	    //System.out.println(obj1.x);
		System.out.println(obj1.y);
		System.out.println(obj1.z);
	}
}
