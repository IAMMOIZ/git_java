class M8 
{
	public static void main(String[] args) 
	{
		String s1 = "10";	
		int i = Integer.parseInt(s1);
		double j = Double.parseDouble(s1);	
		System.out.println(i);
		System.out.println(j);
	}
}

//through a single stmt we can convert string to integer-parseInt
//in the character wrapper class there is no parseChar 
//string doesn't have converting to char 