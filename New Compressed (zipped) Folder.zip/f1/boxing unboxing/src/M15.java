class M15 
{
	public static void main(String[] args) 
	{
		int i = 10;
		Integer obj1 = i;		//Integer obj1 = new Integer(i);   //boxing i to int object
		Integer obj2 = 20;		//Integer obj2 = new Integer(20);  //boxing 20 to int object
		System.out.println("done");
	}
}
