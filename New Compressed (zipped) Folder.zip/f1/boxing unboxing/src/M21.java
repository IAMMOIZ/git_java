class M21 
{
	static void test1(Integer obj)
	{
		System.out.println("test1(Integer)");
	}
	public static void main(String[] args) 
	{
		byte b1 = 10;
		test1(b1);
		System.out.println("done");
	}
}

//Byte primitive can be converted into int primitive, it cann't widening into Integer object