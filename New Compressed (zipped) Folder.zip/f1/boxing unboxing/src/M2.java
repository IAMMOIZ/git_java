class M2 
{
	public static void main(String[] args) 
	{
		Double obj1= new Double(5.5);		//boxing
		Double obj2= Double.valueOf(5.5);	//boxing
		double d1 = obj1.doubleValue();		//un-boxing
		double d2 = obj2.doubleValue();		//un-boxing
		System.out.println("done");
	}
}