class M4 
{
	public static void main(String[] args) 
	{
		boolean flag = false;		
		Boolean b1= new Boolean(flag);	//boxing
		Boolean b2= Boolean.valueOf(flag);	//boxing
		boolean i = b1.booleanValue();		//un-boxing
		boolean j = b2.booleanValue();		//un-boxing
		System.out.println("done");
	}
}

//for boolean primitive whether it is boxing or un-boxing use Boolean wrapper class