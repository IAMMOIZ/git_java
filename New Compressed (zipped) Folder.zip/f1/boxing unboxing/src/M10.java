class M10 
{
	public static void main(String[] args) 
	{
		String s1 = "10r";		//unable to convert string to int because of r
		int i = Integer.parseInt(s1);
		System.out.println("done");
	}
}