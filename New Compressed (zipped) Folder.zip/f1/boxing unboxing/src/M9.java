class M9 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double j = 1.5;
		String s1 = Integer.toString(i);	
		String s2 = Double.toString(j);		
		System.out.println(s1);
		System.out.println(s2);
	}
}