class M13 
{
	public static void main(String[] args) 
	{
		String s1 = "xyz";			
		boolean flag = Boolean.parseBoolean(s1);
		System.out.println(flag);
	}
}

//if something is other than true then considered as a false
//content is true then true otherwise false