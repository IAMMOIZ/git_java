class M20 
{
	public static void main(String[] args) 
	{
		Double obj1 = new Double(20);
		Integer obj2 = new Integer(20);
		Number obj3 = obj1;
		Number obj4 = obj2;
		System.out.println("done");
	}
}

//every numeric wrapper type automatically up casting to Number type