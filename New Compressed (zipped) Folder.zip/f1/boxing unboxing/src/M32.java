class M32 
{
	public static void test(double ... y) 
	{
	}
		public static void test(double[] z)
	{
	}
	
}
