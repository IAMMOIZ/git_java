class M12 
{
	public static void main(String[] args) 
	{
		String s1 = "10.5";			
		double i = Double.parseDouble(s1);
		System.out.println("done");
	}
}

//string into primitive - parseDouble method