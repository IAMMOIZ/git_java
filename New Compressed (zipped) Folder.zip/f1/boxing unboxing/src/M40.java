class M40 
{
	public static void test(Integer b1) 
	{
		System.out.println("Integer");
	}

public static void main(String[] args) 
	{
	
	byte b1=10;
	test(b1);
		}




}
