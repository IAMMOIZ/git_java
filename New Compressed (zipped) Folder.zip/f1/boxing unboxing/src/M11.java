class M11 
{
	public static void main(String[] args) 
	{
		String s1 = "10.5";			//. is allowed only incase of float or double
		int i = Integer.parseInt(s1);
		System.out.println("done");
	}
}