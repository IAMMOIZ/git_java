class M14 
{
	public static void main(String[] args) 
	{
		Integer obj = new Integer(90);			
		int i = obj;		// int i = obj.intValue();
		System.out.println("done");
	}
}
//while using 1.4 or before = compile error
//compile success - if it is 1.5 or later , there is a concept called auto un-boxing
