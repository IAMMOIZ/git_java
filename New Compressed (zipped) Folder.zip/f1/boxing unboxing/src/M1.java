class M1 
{
	public static void main(String[] args) 
	{
		int i=10;
		Integer obj1 = new Integer(i);	//boxing
		Integer obj2 = Integer.valueOf(i);	//boxing
		int j = obj1.intValue();	//un-boxing
		int k = obj2.intValue();	//un-boxing
		System.out.println("done");
	}
}

//primitive content string inside the object is boxing 
//you cann't store any primitive collection
//reading the primitve value from the object is un-boxing
//here i,j,k primitve 
//if i,j,k is int type then used integer wrapper class