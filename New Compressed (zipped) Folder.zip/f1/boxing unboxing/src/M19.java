class M19 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double j = 10.5;
		j = i;
		Double obj1 = new Double(20);
		Integer obj2 = new Integer(20);
		obj1 = obj2;
		System.out.println("done");
	}
}

//widening is only for primitive 
//incase of derived datatype u cann't convert to int object to double object , object to int ... 
//one primtive class cann't converted to other primitive 