class M3 
{
	public static void main(String[] args) 
	{
		Character obj1= new Character('a');		//boxing
		Character obj2= Character.valueOf('a');	//boxing
		char d1 = obj1.charValue();		//un-boxing
		char d2 = obj2.charValue();		//un-boxing
		System.out.println("done");
	}
}