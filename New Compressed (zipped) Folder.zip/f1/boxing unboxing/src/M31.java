class M31 
{
	public static void test(double ... y, String x) 
	{
	}
}

//var arg should always be the last argument.