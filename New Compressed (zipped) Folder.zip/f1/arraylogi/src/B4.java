class  B4
{
	public static void main(String[] args) 
	{
		int[] x={12,30,500,55};

		System.out.println(x.length);
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		System.out.println(x[3]);
		x[0]=100;
		x[1]=34;
		x[2]=56;
		x[3]=46;
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		System.out.println(x[3]);
	}
}

