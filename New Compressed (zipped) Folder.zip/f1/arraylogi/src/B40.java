//remove elements of one array from another array
/*
initial array : 
first array:{1,20,3,1,61,3,19,7,61,9,80};
2nd array:{50,61,3,45,1}
final array:
first array:{20,19,7,9,80}
2nd array:{50,61,3,45,1}
*/

import java.util.Arrays;
class B40
	{
	public static void main(String[] args) 
	{
        int[] x={1,20,3,1,61,3,19,7,61,9,80};
		
		int[] y={50,61,3,45,1};

		System.out.println("initial  first array content:"+Arrays.toString(x));
		System.out.println("initial  second array content:"+Arrays.toString(y));
		int count=0;
		for(int i=0;i<y.length;i++)   //i as index
		{
			for(int j=0;j<(x.length-count);j++)
			{
			if(y[i]==x[j])
			{
			for(int k=j; k<(x.length-count-1);k++)
			{
				x[k]=x[k+1];
			}
            j--;
			count++;
			}
			}
		}
		int[] z=new int[x.length-count];
		for(int i=0;i<z.length;i++)
		{
          z[i]=x[i] ;
		}
		System.out.println("final array content:"+Arrays.toString(z));
		System.out.println("final array content:"+Arrays.toString(y));
		
	}
}