//remove duplicates  elements from an array
/*
initial array : {1,20,3,1,61,3,19,7,61,9,80};
final {1,20,3,61,19,7,9,80}
*/

import java.util.Arrays;
class B39
	{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,61,3,19,7,22,9,80};
		int count=0;
		int[] y=new int[0];
		System.out.println("initial array content:"+Arrays.toString(x));
		for(int i=0;i<x.length;i++)
		{
			for(int j=i;j<x.length;j++)
			{
			if(x[j]==x[i])
			{
				count++;
			}
			}

		}
		int[] y=new int[x.length-count];
		for(int i=0;i<x.length;i++)
		{
			for(int j=++i;j<x.length;j++)
				{
					if(x[i]==x[j])
					{
						i++;
					}
					else
					{
					y[i]=y[j];
					}
				}
		}
		System.out.println("final array content:"+Arrays.toString(y));
		
	}
}