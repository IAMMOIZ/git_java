//develop third array with the common elements of given two arrays
/*
initial arrays content:
first array:{1,20,3,1,61,3,19,7,61,9,80}
second array:{50,61,3,45,1}
final arrays content:
third array:{1,3,61}
*/    
class B41
{
	public static void main(String[] args) 
	{
        int[] x={1,20,3,1,61,3,19,7,61,9,80};
		
		int[] y={50,61,3,45,1};

		System.out.println("initial  first array content:"+Arrays.toString(x));
		System.out.println("initial  second array content:"+Arrays.toString(y));
		int size=x.length < y.length?x.length:y.length;
		int[] z= new int[size];
	    int count=0;
		for(int i=0;i<x.length;i++)   //i as index
		{
			for(int j=0;j<y.length;j++)
			{
			if(x[i]==y[j])
			{
				boolean isAvailable=false;
				
			for(int k=0; k<z.length;k++)
			{
				if(x[i]==z[k])
				{
				isAvailable=true;
				break;
				}
				
			}
            if(!isAvailable)
			{
				z[count++]=x[i];
			}
			}
			}
		}
		int[] z1=new int[count];
		for(int i=0;i<z1.length;i++)
		{
          z1[i]=z[i] ;
		}
		System.out.println("third array content:"+Arrays.toString(z1));
		
	}
}