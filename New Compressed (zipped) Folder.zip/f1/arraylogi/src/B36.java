//remove all single digit elements from an array
/*
initial : {1,2,3,5,61,3,19,7,22,9,80}
final:{20,61,19,22,80}
*/
//inset two new element from index number 4 . new elements are 100,40;
//1,2,3,5,6,3,9,7,2,9,8
//1,2,3,5,100,40,6,3,9,7,2,9,8
import java.util.Arrays;
class B36


{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,61,3,19,7,22,9,80};
		int count=0;
		System.out.println("initial array content:"+Arrays.toString(x));
		for(int i=0;i<x.length;i++)
		{
			if(x[i]<10)
			{
				for(int j=i;j<(x.length-1-count);j++)
				{
					x[j]=x[j+1];
				}
				i--;
				count++;
			}
		}
		int[] y=new int[x.length-count];
		for(int i=0;i<y.length;i++)
		{
		y[i]=x[i];
		}
		System.out.println("final array content:"+Arrays.toString(y));
		
	}
}