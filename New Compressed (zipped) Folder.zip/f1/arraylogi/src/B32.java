import java.util.Arrays;
class B32

{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,6,3,9,7,2,9,8};
		
	   System.out.println("initial array content:"+Arrays.toString(x));
      int[] y=new int[x.length-1];
	  for(int i=0;i<4;i++)
		{
          y[i]=x[i];
	   }

		for(int i=4;i<y.length;i++)
		{
			y[i]=x[i+1];
		}
		System.out.println("final array content:"+Arrays.toString(y));
	}
}
//remove an element at index number 4 without making any duplicates
//1,2,3,5,6,3,9,7,2,9,8
//1,2,3,5,3,9,7,2,9,8