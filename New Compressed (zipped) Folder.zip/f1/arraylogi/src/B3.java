class  B3
{
	public static void main(String[] args) 
	{
		int[] x=new int[3];

		System.out.println(x.length);
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		x[0]=100;
		x[1]=34;
		x[2]=56;
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}
}

