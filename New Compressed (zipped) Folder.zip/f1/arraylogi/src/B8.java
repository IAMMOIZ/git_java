import java.util.Arrays;     //built in method
class  B8
{
	public static void main(String[] args) 
	{
		int[] x={12,30,500,55};
		System.out.print(Arrays.toString(x));


}
}

