import java.util.Arrays;
class  P23
{
	public static void main(String[] args) 
	{
		int[] x={1,2,3,5,6,3,9,7,2,9,8};
		//       0 1 2 3 4 5 6 7 8 9 10
		//output should be 2,3,6,9
		System.out.println("array content:"+ Arrays.toString(x));
         for(int i=1;i<x.length;i+=2)
		{
		 int temp=x[i];
		 x[i]=x[i-1];
		 x[i-1]=temp;
		 }
		
		
		System.out.println("final array content:"+Arrays.toString(x));
		}
	}

//swap even indexed elements with immediate odd indexed elements