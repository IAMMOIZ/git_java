class A13 
{
	public static void main(String[] args) 
	{
	    int x[] ={1,2,3,4,5,6,7,8,9,10,0};
		int element=10;
		int index=-1;
		for(int i=0;i<x.length;i++)
		{
		    if(x[i]==element)
			{
			   index=i;
			   break;
			}
		}
		System.out.println(index);
	}
}
