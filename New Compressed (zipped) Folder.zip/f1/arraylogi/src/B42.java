//develop third array with the uncommon elements of given two arrays
/*
initial arrays content:
first array:{1,20,3,1,61,3,19,7,61,9,80}
second array:{50,61,3,45,1}
final arrays content:
third array:{20,19,7,9,80,50,45}
*/    

class B42
{
	public static void main(String[] args) 
	{
        int[] x={1,20,3,1,61,3,19,7,61,9,80};
		
		int[] y={50,61,3,45,1};

		System.out.println("initial  first array content:"+Arrays.toString(x));
		System.out.println("initial  second array content:"+Arrays.toString(y));
		int size=x.length + y.length;
		int[] z= new int[size];
	    int count=0;
		boolean isAvailable=false;
		for(int i=0;i<x.length;i++)   
		{
			for(int j=0;j<y.length;j++)
			{
			if(x[i]==y[j])
			{
				isAvailable=true;
				break;
			}
			}
			if(!isAvailable)
			{
				z[count++]=x[i];
			}
			isAvailable=false;
			}
			

			 for(int i=0;i<y.length;i++)   
		    {
			for(int j=0;j<x.length;j++)
			{
			if(y[i]==x[j])
			{
				isAvailable=true;
				break;
			}
			}
			if(!isAvailable)
			{
				z[count++]=y[i];
			}
			isAvailable=false;
			}

		int[] z1=new int[count];
		for(int i=0;i<z1.length;i++)
		{
          z1[i]=z[i] ;
		}
		System.out.println("third array content:"+Arrays.toString(z1));
		
	}
}