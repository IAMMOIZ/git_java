class  B1
{
	public static void main(String[] args) 
	{
		int[] x={10,30,50,60};

		System.out.println(x.length);
		System.out.println(x[0]);
		System.out.println(x[2]);
	}
}
