import java.util.Arrays;
class B28 
{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,6,3,9,7,2,9,8};
   
       
	   System.out.println("initial array content:"+Arrays.toString(x));
       int temp=x[x.length-1];  
	   
		for( int i=x.length-1;i>0;i--)
		{
	        x[i]=x[i-1];
		}
		 x[0]=temp;

		System.out.println("final array content:"+Arrays.toString(x));
	}
}
//right rotate by one
//1,2,3,5,6,3,9,7,2,9,8
//8,1,2,3,5,6,3,9,7,2,9