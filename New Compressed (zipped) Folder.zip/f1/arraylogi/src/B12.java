import java.util.Arrays;
class  B12
{
	public static void main(String[] args) 
	{
		int[] x={12,30,500,55,5,35,50,2,0,34};
		System.out.println("array content:"+ Arrays.toString(x));
        System.out.println(" Even numbers :");
        for(int i=0; i< x.length;i++)
        {

			if(x[i]%2==0)
			{
				System.out.print(x[i]+",");
		    }
		}
	}
}

//print even numbers