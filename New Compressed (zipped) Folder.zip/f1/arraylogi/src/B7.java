class  B7
{
	public static void main(String[] args) 
	{
		int[] x={12,30,500,55};



        for(int i:x)
		{
		System.out.print(i+",");
		}



}
}

