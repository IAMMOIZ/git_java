class  B5
{
	public static void main(String[] args) 
	{
		int[] x={12,30,500,55};



        for(int i=0;i<x.length;i++)
		{
		System.out.println(x[i]);
		}



}
}

