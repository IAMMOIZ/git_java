//find out all missed numbers from a given int array between min and max values
/*
initial arrays content:
given array:{3,7,15,9,1,12,5}
missed elements:2,4,6,8,10,11,13,14
*/    

class B43
{
	public static void main(String[] args) 
	{
        int[] x={3,7,15,9,1,12,5};
		
		
		int min=x[0],max=x[0];
	
		for(int i=1;i<x.length;i++)   
		{
			if(x[i]<min)
			{
			min=x[i];
			}
			if(x[i]>max)
			{
			max=x[i];
			}
		}
		int[] y=new int[max+1];
			for(int i=0;i<x.length;i++)
			{
				y[x[i]]=min-5;
			}
			System.out.println("missed elements:");
			 for(int i=min+1;i<y.length;i++)   
		    {
			
			if(y[i]!=(min-5))
			{
				System.out.print(i+",");
				}
			}
		
	}
}