class  B2
{
	public static void main(String[] args) 
	{
		int[] x=new int[20];

		System.out.println(x.length);
		System.out.println(x[0]);
		System.out.println(x[2]);
	}
}

//default values are 0