import java.util.Arrays;
class B29 
{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,6,3,9,7,2,9,8};
		
	   System.out.println("initial array content:"+Arrays.toString(x));
      
		int temp=x[4];
		int temp1;
		x[4]=100;
		for(int i=5;i<=x.length-1;i++)
		{
			temp1=x[i];
			x[i]=temp;
			temp=temp1;
		}
   
  
  
  

	  
		System.out.println("final array content:"+Arrays.toString(x));
	}
}
//insert a new element at 4th index.new element is 100.
//1,2,3,5,6,3,9,7,2,9,8
//1,2,3,5,100,6,3,9,7,2,9