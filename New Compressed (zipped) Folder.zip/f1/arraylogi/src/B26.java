import java.util.Arrays;
class B26 
{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,6,3,9,7,2,9,8};
   
       
	   System.out.println("initial array content:"+Arrays.toString(x));
     
	   int temp=x[0] ;

		for( int i=0;i<x.length-1;i++)
		{
        x[i]=x[i+1];
		}
		x[x.length-1]=temp;
        

		System.out.println("final array content:"+Arrays.toString(x));
	}
}
//left rotate by one
//1,2,3,5,6,3,9,7,2,9,8
//2,3,5,6,3,9,7,2,9,8,1