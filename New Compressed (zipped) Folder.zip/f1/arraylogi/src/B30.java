import java.util.Arrays;
class B30

{
	public static void main(String[] args) 
	{
        int[] x={1,2,3,5,6,3,9,7,2,9,8};
		
	   System.out.println("initial array content:"+Arrays.toString(x));
      
		for(int i=4;i<x.length-1;i++)
		{
			x[i]=x[i+1];
		}

		System.out.println("final array content:"+Arrays.toString(x));
	}
}
//remove an new element at 4th index.
//1,2,3,5,6,3,9,7,2,9,8
//1,2,3,5,3,9,7,2,9,8,8